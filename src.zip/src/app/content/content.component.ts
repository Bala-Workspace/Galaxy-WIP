import { Component, OnInit } from '@angular/core';
import { User } from "../user";

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {

  public genders = ["Male", "Female"];

  public userModel = new User("", "", "", null);

  constructor() { }

  ngOnInit(): void {
  }

  onSubmit() {
    console.log(this.userModel);
  }

}
