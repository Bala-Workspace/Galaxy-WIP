export class User {
    constructor(
        public fname: string,
        public lname: string,
        public gender: string,
        public age: number
    ){}
}
