import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

/* Prime NG modules */
import { CalendarModule } from 'primeng/calendar';
import { StepsModule } from 'primeng/steps';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { OverlayPanelModule } from 'primeng/overlaypanel';

import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HttpService } from './services/http.service';


@NgModule({
  declarations: [HeaderComponent, FooterComponent],
  imports: [
    CommonModule, ReactiveFormsModule,
    HttpClientModule, OverlayPanelModule,
    ToastModule, DialogModule, StepsModule, CalendarModule
  ],
  providers: [HttpService],
  exports: [HeaderComponent,
    FooterComponent, ReactiveFormsModule,
    OverlayPanelModule, ToastModule, DialogModule, StepsModule, CalendarModule]
})
export class SharedModule { }
