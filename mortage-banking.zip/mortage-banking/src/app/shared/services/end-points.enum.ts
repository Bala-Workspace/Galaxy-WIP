export enum EndPoints {
    ACCOUNTS = 'accounts',
    LOGIN = 'login',
    MARTGAGE = 'martgage/accounts'
}
