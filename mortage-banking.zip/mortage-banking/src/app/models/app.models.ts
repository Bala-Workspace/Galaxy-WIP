export interface ACCOUNTS {
    accountNumber: string;
    password: string;
    accountType: string;
    customerName: string;
    dob: string;
}

export interface MORTGAGEREQUEST {
    accountNumber: string;
    age: number;
    mortgageType: string;
    salaryAmount: number;
    propertyCost: number;
    percentage: number;
}

export interface MORTGAGERESPONSE {
    message: string;
    statusCode: number;
    mortgageAccNo: string;
    password: string;
}


export interface LOGINREQUEST {
    accountNumber: string;
    password: string;
}

export interface LOGINRESPONSE {
    message: string;
    statusCode: number;
    savingAccountNumber: number;
    mortgageAccountNumber: number;
    customerName: string;
}

export interface ACCOUNTSUMMARYRESPONSE {
    message: string;
    statusCode: number;
    summaries: ACCOUNTSUMMERIES[];
}

export interface ACCOUNTSUMMERIES {
    transactionDate: string;
    transactionType: string;
    mortgageType: string;
    paidAmount: number;
    balanceAmount: number;
}

export interface FUNDTRANSFERREQUEST {
    mortgageAccountNumber: string;
    // savingAccountNumber: string;
    transferAmount: string;
    transactionType: string;

}
export interface FUNDTRANSFERRESPONSE {
    message: string;
    stattusCode: number;
}
