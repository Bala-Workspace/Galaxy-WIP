import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';


@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  display = false;

  searchAccount: FormGroup;
  createMortgageForm: FormGroup;

  constructor() { }

  ngOnInit() {
    this.searchAccount = new FormGroup({
      accountNumber: new FormControl()
    });
    this.createMortgageForm = new FormGroup({
      propertyValue: new FormControl(null),
      propertyCity: new FormControl(null)
    });
  }
  showDialog() {
    this.display = true;
  }
}
